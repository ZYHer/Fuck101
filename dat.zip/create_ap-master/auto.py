import os
os.system('sudo create_ap wlan0 eth0 Fuck101-ByLGRD-ZYH fuckyou101')
