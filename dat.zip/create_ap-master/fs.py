import os
os.system('sudo mount -o iocharset=utf8 /dev/sda1 /var/www/html/usb')
#os.system('sudo ln -s /var/www/html/data/User/fuck101/home/USB/* /var/www/html/usb')
os.system('sudo service nginx start')
os.system('sudo service nginx restart')

